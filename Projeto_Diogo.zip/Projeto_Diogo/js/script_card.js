
// --- FUNÇÕES DE UTILIDADE ---

function formatar_moeda(valor){
    return new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(valor);
}

// --- FUNÇÕES DE CARD ---

/**
 * Cria o elemento HTML (card) para um único veículo.
 * @param {object} veiculo - Objeto com os dados do veículo (marca, modelo, preco_por_dia, etc.)
 * @returns {HTMLElement} O elemento Article do card
 */
function criar_card_veiculo(veiculo) {
    const artigo = document.createElement('article');
    // Adiciona a classe de coluna para o grid do Bootstrap
    artigo.className = 'col'; 
    
    // Organização mais limpo e usando as classes Bootstrap para formatar
    artigo.innerHTML = `
        <div class="card h-100 shadow-sm">
            <img src="${veiculo.imagem || 'https://via.placeholder.com/400x250?text=Veículo'}" class="card-img-top" alt="${veiculo.modelo || ''}" style="height: 180px; object-fit: cover;">
            <div class="card-body d-flex flex-column">
                <h5 class="card-title mb-1">${veiculo.marca} ${veiculo.modelo}</h5>
                <p class="card-text text-muted mb-3">${veiculo.categoria || '—'} • ${veiculo.cidade || 'Cidade'}</p>
                <h4 class="text-success mt-auto">${formatar_moeda(veiculo.preco_por_dia)} <small class="text-muted fs-6">/ dia</small></h4>
            </div>
            <div class="card-footer d-flex justify-content-between">
                <button class="btn btn-success btnReservar" data-id="${veiculo.id}">Reservar</button>
                <button class="btn btn-outline-secondary btnDetalhes" data-id="${veiculo.id}">Detalhes</button>
            </div>
        </div>
    `;
    
  
    return artigo;
}

/**
 * Renderiza os veículos na grade principal (Grid).
 * @param {Array<object>} veiculos - Lista de veículos a serem exibidos.
 */
function renderizar_veiculos(veiculos) {
    const grid = document.getElementById('vehiclesGrid');
    grid.innerHTML = '';
    document.getElementById('noResults').style.display = 'none';

    if (!veiculos || veiculos.length === 0) {
        document.getElementById('noResults').style.display = 'block';
        return;
    }

    veiculos.forEach(veiculo => {
        // Usa a função criar_card_veiculo
        grid.appendChild(criar_card_veiculo(veiculo));
    });
}