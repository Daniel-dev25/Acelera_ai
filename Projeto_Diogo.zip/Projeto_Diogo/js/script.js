// VARIÁVEIS GLOBAIS (Acessíveis em render_card.js)
let todos_veiculos = [];

// Caminho para carregar os dados locais
const URL_JSON = 'data/produtos.json'; 

// --- FUNÇÕES DE LÓGICA DE FILTRO ---

/**
 *  Popula os <select> de Marca e Cidade com base nos dados do JSON.
 
 */
function popular_selects_dinamicos() {
    // Usamos Set para garantir apenas valores únicos
    const marcas = new Set();
    const cidades = new Set();

    todos_veiculos.forEach(veiculo => {
        if (veiculo.marca) marcas.add(veiculo.marca);
        if (veiculo.cidade) cidades.add(veiculo.cidade);
    });

    // Função auxiliar para preencher os selects (Requer jQuery)
    const preencher_select = (id, valores) => {
        const $select = $(`#${id}`);
        $select.find('option:not(:first)').remove(); // Limpa opções antigas (exceto a primeira 'Todos')
        valores.forEach(valor => {
            $select.append(`<option value="${valor}">${valor}</option>`);
        });
    };

    preencher_select('filterMarca', marcas);
    preencher_select('filterCidade', cidades);
}

// --- NOVO: FUNÇÃO DE ORDENAÇÃO ---

/**
 * Ordena o array de veículos com base na opção selecionada.
 * @param {Array} veiculos - Lista de veículos a serem ordenados.
 * @param {string} criterio - Critério de ordenação ('nome_asc', 'nome_desc', 'preco_asc', 'preco_desc').
 * @returns {Array} O array de veículos ordenado.
 */
function ordenar_veiculos(veiculos, criterio) {
    if (!criterio) return veiculos;

    veiculos.sort((a, b) => {
        switch (criterio) {
            case 'nome_asc':
                return a.modelo.localeCompare(b.modelo);
            case 'nome_desc':
                return b.modelo.localeCompare(a.modelo);
            case 'preco_asc':
                // Converte para número para comparação correta
                return parseFloat(a.preco_por_dia) - parseFloat(b.preco_por_dia);
            case 'preco_desc':
                // Converte para número para comparação correta
                return parseFloat(b.preco_por_dia) - parseFloat(a.preco_por_dia);
            default:
                return 0;
        }
    });

    return veiculos;
}


/**
 * Aplica os filtros (Nome/Modelo, Marca, Cidade, Categoria e Faixa de Preço) na lista de veículos.
 */
function aplicar_busca() {
    // 1. CAPTURA DOS FILTROS
    const nome_busca = document.getElementById('filterNome').value.toLowerCase(); 
    const marca_selecionada = document.getElementById('filterMarca').value;
    const cidade_selecionada = document.getElementById('filterCidade').value;
    const categoria_selecionada = document.getElementById('category').value; 
    
    // NOVO: CAPTURA DO CRITÉRIO DE ORDENAÇÃO
    const criterio_ordenacao = document.getElementById('sortOrder').value;
    
    // 2. CAPTURA DOS FILTROS DE PREÇO
    const preco_minimo = parseFloat(document.getElementById('minPrice').value);
    const preco_maximo = parseFloat(document.getElementById('maxPrice').value);
    
    // 3. APLICAÇÃO DOS FILTROS
    let veiculos_filtrados = todos_veiculos.filter(veiculo => {
        
        // --- FILTRO POR NOME/MODELO (Filtra o texto digitado apenas no MODELO) ---
        const corresponde_nome = !nome_busca || veiculo.modelo.toLowerCase().includes(nome_busca);
        
        // --- FILTRO POR SELECTS ---
        const corresponde_marca = !marca_selecionada || veiculo.marca === marca_selecionada;
        const corresponde_cidade = !cidade_selecionada || veiculo.cidade === cidade_selecionada;
        const corresponde_categoria = !categoria_selecionada || veiculo.categoria === categoria_selecionada;
        
        // --- FILTRO POR FAIXA DE PREÇO ---
        const preco_veiculo = parseFloat(veiculo.preco_por_dia);

        const corresponde_preco = 
            (isNaN(preco_minimo) || preco_veiculo >= preco_minimo) &&
            (isNaN(preco_maximo) || preco_veiculo <= preco_maximo);


        // Retorna TRUE apenas se TODOS os filtros corresponderem
        return corresponde_nome && 
               corresponde_marca && 
               corresponde_cidade && 
               corresponde_categoria && 
               corresponde_preco;
    });
    
    // 4. APLICAÇÃO DA ORDENAÇÃO (NOVO PASSO)
    veiculos_filtrados = ordenar_veiculos(veiculos_filtrados, criterio_ordenacao);

    renderizar_veiculos(veiculos_filtrados); // Função em render_card.js
}

/**
 * Função de carregamento inicial dos dados via AJAX.
 */
function carregar_veiculos() {
    const grid = document.getElementById('vehiclesGrid');
    grid.innerHTML = 'Carregando veículos...';

    // MUDANÇA CHAVE: Usando $.getJSON com o caminho local
    $.getJSON(URL_JSON, function(res) {
        todos_veiculos = res;
        popular_selects_dinamicos(); 
        aplicar_busca(); 
    }).fail(function(jqxhr, textStatus, error) {
        grid.innerHTML = `<div class="alert alert-danger">Erro ao carregar veículos. Verifique o caminho JSON (${URL_JSON}) ou se o Live Server está ativo.</div>`;
        console.error('Erro ao carregar JSON:', textStatus, error);
    });
}

// --- FUNÇÕES DO MODAL ---

/**
 * Calcula a diferença em dias entre as datas de início e fim e atualiza o preço total.
 */
function calcular_diarias() {
    const dataInicioInput = document.getElementById('bookStart').value;
    const dataFimInput = document.getElementById('bookEnd').value;
    const veiculoId = document.getElementById('vehicleId').value;
    
    // Converte as strings de data para objetos Date
    const dataInicio = new Date(dataInicioInput);
    const dataFim = new Date(dataFimInput);

    // 1. Encontra o preço diário do veículo
    const veiculo = todos_veiculos.find(v => v.id === parseInt(veiculoId));
    
    // Verifica se os campos estão preenchidos e válidos
    if (!veiculo || !dataInicioInput || !dataFimInput || isNaN(dataInicio) || isNaN(dataFim) || dataFim <= dataInicio) {
        // Mostra zero se as datas forem inválidas, não preenchidas ou a data final for antes da inicial
        $('#totalReserva').text('Total: R$ 0,00');
        return;
    }

    const precoDiaria = parseFloat(veiculo.preco_por_dia);
    
    // 2. Calcula a diferença em milissegundos
    const diferencaTempo = dataFim.getTime() - dataInicio.getTime();
    
    // 3. Converte milissegundos para dias (1000ms * 60s * 60min * 24h)
    // Usamos Math.ceil para garantir que qualquer fração de dia conte como um dia inteiro
    const diferencaDias = Math.ceil(diferencaTempo / (1000 * 3600 * 24)); 
    
    // Se a diferença for zero, a pessoa alugou por 1 dia mínimo
    const totalDias = diferencaDias > 0 ? diferencaDias : 1; 

    // 4. Calcula o total
    const valorTotal = precoDiaria * totalDias;
    
    // 5. Atualiza o HTML (formatar_moeda deve estar no render_card.js)
    const textoTotal = formatar_moeda(valorTotal);
    $('#totalReserva').text(`Total (${totalDias} dias): ${textoTotal}`);
}


/**
 * Abre o modal para reserva.
 */
function abrir_modal_reserva(id_veiculo){
    // 1. Garante que qualquer conteúdo de detalhe anterior seja limpo
    fechar_modal(); 
    
    document.getElementById('vehicleId').value = id_veiculo;
    // Oculta a descrição de detalhes se estiver visível
    $('#modalDetalhesCorpo').remove(); 
    $('#bookingForm').show(); 
    $('#modalTitle').text(`Reservar veículo`); 
    
    // *** NOVO: CHAMA O CÁLCULO INICIAL APÓS ABRIR O MODAL ***
    // (Pequeno delay para garantir que os campos de data estejam prontos no DOM)
    setTimeout(calcular_diarias, 100); 

    const modal = new bootstrap.Modal(document.getElementById('modalBackdrop'));
    modal.show();
}

/**
 * Abre o modal para detalhes ()
 */
function abrir_detalhes_modal(id_veiculo) {
    // 1. Limpa o modal antes de injetar novo conteúdo
    fechar_modal(); 
    
    const veiculo = todos_veiculos.find(v => v.id === id_veiculo);
    if (!veiculo) return;

    // Obtém a função de formatação do outro arquivo (formatar_moeda)
    const preco = formatar_moeda(veiculo.preco_por_dia); 
    const descricao = `
        Este é um ${veiculo.modelo}, pertencente à categoria <strong>${veiculo.categoria}</strong>. 
        Ideal para quem busca mobilidade na região de <strong>${veiculo.cidade}</strong>. 
        O valor médio de aluguel é de ${preco} por dia.
    `;

    const $modal = $('#modalBackdrop');
    $modal.find('#modalTitle').text(`Detalhes: ${veiculo.marca} ${veiculo.modelo}`);

    // Cria e injeta a descrição no corpo do modal
    const corpo_detalhes = `
        <div id="modalDetalhesCorpo">
            <p class="text-muted">Categoria: <strong>${veiculo.categoria}</strong></p>
            <p class="lead text-success mb-3">Preço Médio: ${preco} / dia</p>
            <hr>
            <p>${descricao}</p>
            <div class="alert alert-info mt-3">Para reservar, clique no botão "Cancelar" e depois em "Reservar" no card principal.</div>
        </div>
    `;
    
    // Injeta antes de tudo no modal-body e esconde o formulário de reserva
    $modal.find('.modal-body').prepend(corpo_detalhes);
    $modal.find('#bookingForm').hide(); 

    const modal_instancia = new bootstrap.Modal(document.getElementById('modalBackdrop'));
    modal_instancia.show();
}


function fechar_modal(){
    // Remove o conteúdo de detalhes injetado e mostra o form
    $('#modalDetalhesCorpo').remove();
    $('#bookingForm').show();
    $('#modalTitle').text(`Reservar veículo`); 
    
    const instancia_modal = bootstrap.Modal.getInstance(document.getElementById('modalBackdrop'));
    if (instancia_modal) {
        instancia_modal.hide();
    }
    document.getElementById('bookingForm').reset();
}

/**
 * Simula o envio de dados de reserva (POST) para um servidor.
 */
function enviar_reserva(dados){
    return new Promise((resolver) => {
         setTimeout(() => {
            resolver({ codigo: 'RES' + Math.floor(Math.random() * 900) + 100 });
         }, 500);
    });
}


// --- INICIALIZAÇÃO ---

document.addEventListener('DOMContentLoaded', function(){
    carregar_veiculos(); 

    // Event Listeners para a busca e filtro
    document.getElementById('btnSearch').addEventListener('click', aplicar_busca);
    document.getElementById('filterNome').addEventListener('keyup', aplicar_busca); 
    
    // NOVO: Listener para o filtro de ordenação
    const sortSelect = document.getElementById('sortOrder');
    if (sortSelect) {
        sortSelect.addEventListener('change', aplicar_busca);
    }
    
    // NOVO: Listeners para o cálculo de diárias no modal
    const bookStart = document.getElementById('bookStart');
    const bookEnd = document.getElementById('bookEnd');
    
    if (bookStart && bookEnd) {
        bookStart.addEventListener('change', calcular_diarias);
        bookEnd.addEventListener('change', calcular_diarias);
    }
    
    // --- DELEGAÇÃO DE EVENTOS PARA OS BOTÕES DENTRO DOS CARDS (USANDO JQUERY) ---
    const $grid = $('#vehiclesGrid');
    
    // Listener Único para o botão RESERVAR
    $grid.on('click', '.btnReservar', function(e) {
        const id = parseInt($(this).data('id')); 
        abrir_modal_reserva(id);
    });

    // Listener Único para o botão DETALHES
    $grid.on('click', '.btnDetalhes', function(e) {
        const id = parseInt($(this).data('id'));
        abrir_detalhes_modal(id);
    });
    // FIM DA DELEGAÇÃO DE EVENTOS

    // Submissão do Formulário de Reserva
    document.getElementById('bookingForm').addEventListener('submit', function(e){
        e.preventDefault();
        const payload = { 
            vehicleId: document.getElementById('vehicleId').value,
            name: document.getElementById('bookName').value,
            phone: document.getElementById('bookPhone').value,
            email: document.getElementById('bookEmail').value,
            start: document.getElementById('bookStart').value,
            end: document.getElementById('bookEnd').value
        }; 
        
        enviar_reserva(payload).then((resp) => {
            alert('Reserva confirmada! Código de simulação: ' + resp.codigo);
            fechar_modal();
        });
    });
});